clear
SimForPaper = 0     % Define this variable just for resetting variables in run_me_module.m.

%===== Parameters of simulation =====
model = 'InvPen';
AnOn = 1e-4; % Online noise
AnOff = 1e-4;  % Offline noise
kFrom = 4; kTo = 14; kDelta = 1; 
Nd1 = 1; % Nd for (A,B) average        
Nd2 = 100; % Nd for YU average
SkipDeePC = false; % true to skip DeePC simulation
pinv_threshold = []; % [] : Use MATLAB default for Truncated SVD, or assign like 1.5e-1
NoTr = 20;    % Number of Trial
%====================================

Alld2pc = []; Alldeepc = []; 
for k_ = kFrom:kDelta:kTo
    jNbar = k_;  kTini = k_;    
        
    fprintf('-------- SIMULATION: PARA = %d -------------------- \n', k_);
    
    run_me_v4
    
    Alld2pc = [Alld2pc; MAEd2pc jNbar ];
    Alldeepc = [Alldeepc; MAEdeepc kTini ];
end

d2p1 = Alld2pc(:,1); xx = Alld2pc(:,2);  %nx
dee1 = Alldeepc(:,1); 
        
        
figure(11)
clf
xlab='Nbar'; ylab='MAE';

subplot(222)
plot(xx,d2p1,'rO-',xx,dee1,'bX-')
grid on
legend('D2PC','DeePC')
ylim([0 20])
axis([4 14 0 20])
title('D2PC vs DeePC')
xlabel(xlab);ylabel(ylab);
        