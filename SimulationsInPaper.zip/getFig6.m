clear
SimForPaper = 0     % Define this variable just for resetting variables in run_me_module.m.

%===== Parameters of simulation =====
model = 'FourTank';
AnOn = 0.1; % Online noise
AnOff = 0.1;  % Offline noise
kFrom = 4; kTo = 70; kDelta = 2; 
Nd1 = 1; % Nd for (A,B) average        
Nd2 = 1; % Nd for YU average
SkipDeePC = false; % true to skip DeePC simulation
pinv_threshold = []; % [] : Use MATLAB default for Truncated SVD, or assign like 1.5e-1
NoTr = 20;    % Number of Trial
%====================================

Alld2pc = []; Alldeepc = []; 
for k_ = kFrom:kDelta:kTo
    jNbar = k_;  kTini = k_;    
    fprintf('-------- SIMULATION: PARA = %d -------------------- \n', k_);
    
    run_me_v4
    
    Alld2pc = [Alld2pc; MAEd2pc jNbar ];
    Alldeepc = [Alldeepc; MAEdeepc kTini ];
end

d2p1 = Alld2pc(:,1); xx = Alld2pc(:,2);  %nx
dee1 = Alldeepc(:,1);         

xlab='Nbar'; ylab='MAE';
figure(11)
clf
subplot(221)
plot(xx,d2p1,'r-',xx,dee1,'b:');    xlim([4 20])
xlabel(xlab);ylabel(ylab);grid;legend('D2PC','DeePC')
ylim([0 0.6])
subplot(222)
plot(xx,d2p1,'r-',xx,dee1,'b:');    xlim([20 70])
xlabel(xlab);ylabel(ylab);grid;legend('D2PC','DeePC')
        