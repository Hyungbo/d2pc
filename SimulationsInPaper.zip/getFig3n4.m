clear
SimForPaper = 0     % Define this variable just for resetting variables in run_me_module.m.

%===== Parameters of simulation =====
model = 'TwoCart';
AnOn = 0.1; % Online noise
AnOff = 0.1;  % Offline noise
kFrom = 4; kTo = 70; kDelta = 2; 
Nd1 = 1; % Nd for (A,B) average        
Nd2 = 100; % Nd for YU average
SkipDeePC = false; % true to skip DeePC simulation
pinv_threshold = []; % [] : Use MATLAB default for Truncated SVD, or assign like 1.5e-1
NoTr = 20;    % Number of Trial
%====================================

Alld2pc = []; Alldeepc = []; 
for k_ = kFrom:kDelta:kTo
    jNbar = k_;  kTini = k_;    
        
    fprintf('-------- SIMULATION: PARA = %d -------------------- \n', k_);
    
    run_me_v4
    
    Alld2pc = [Alld2pc; MAEd2pc jNbar rTimeOff_d2pc rTimeOn_d2pc];
    Alldeepc = [Alldeepc; MAEdeepc kTini rTimeOff_deepc rTimeOn_deepc];
end

d2p1 = Alld2pc(:,1); xx = Alld2pc(:,2);  %nx
dee1 = Alldeepc(:,1); 
d2p1R = Alld2pc(:,3:4); dee1R = Alldeepc(:,3:4);     
        

%===== Parameters of simulation =====
model = 'TwoCart';
AnOn = 0.1; % Online noise
AnOff = 0.1;  % Offline noise
kFrom = 4; kTo = 70; kDelta = 2; 
Nd1 = 100; % Nd for (A,B) average        
Nd2 = 1; % Nd for YU average
SkipDeePC = true;
pinv_threshold = []; % [] : Use MATLAB default for Truncated SVD, or assign like 1.5e-1
%NoTr = 20;    % Number of Trial
%====================================

Alld2pc = []; Alldeepc = []; 
for k_ = kFrom:kDelta:kTo
    jNbar = k_;  kTini = k_;    
    fprintf('-------- SIMULATION: PARA = %d -------------------- \n', k_);
   
    run_me_v4
    
    Alld2pc = [Alld2pc; MAEd2pc jNbar rTimeOff_d2pc rTimeOn_d2pc];
    Alldeepc = [Alldeepc; MAEdeepc kTini rTimeOff_deepc rTimeOn_deepc];
end
      
d2p2 = Alld2pc(:,1); 
d2p2R = Alld2pc(:,3:4); 
xlab = 'Nbar'; ylab = 'MAE';

figure(11)
xlim1=[20 70];
subplot(221)
plot(xx,d2p1,'r-',xx,dee1,'b--',xx,d2p2,'r-.');
legend('D2PC','DeePC','D2PC(av1)')
xlabel(xlab);ylabel(ylab);grid;
xlim([4 20]); ylim([0 1])
subplot(222)
plot(xx,d2p1,'r-',xx,dee1,'b--',xx,d2p2,'r-.');
legend('D2PC','DeePC','D2PC(av1)')
xlabel(xlab);ylabel(ylab);grid;
xlim([20 70]);ylim([0.01 0.04])

d2p1off=d2p1R(:,1); d2p1on=d2p1R(:,2);
dee1off=dee1R(:,1); dee1on=dee1R(:,2);

subplot(223)
d2p2off=d2p2R(:,1); d2p2on=d2p2R(:,2);
plot(xx,d2p1off,'r-',xx,dee1off,'b--',xx,d2p2off,'r-.');
legend('D2PC','DeePC','D2PC(av1)')
xlabel(xlab); ylabel('sec');grid on
xlim(xlim1);
title('Offline computation time ')
subplot(224)
plot(xx,d2p1on,'r-',xx,dee1on,'b--',xx,d2p2on,'r-.');
legend('D2PC','DeePC','D2PC(av1)')
xlabel(xlab); ylabel('sec');grid on
xlim(xlim1);
title('Online computation time ')
