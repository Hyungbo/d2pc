clear
SimForPaper = 0     % Define this variable just for resetting variables in run_me_module.m.

%===== Parameters of simulation =====
model = 'TwoCart';
AnOn = 0.1; % Online noise
AnOff = 0;  % Offline noise
kFrom = 4; kTo = 70; kDelta = 2; 
Nd1 = 1; % Nd for (A,B) average        
Nd2 = 1; % Nd for YU average
SkipDeePC = true; % true to skip DeePC simulation
pinv_threshold = []; % [] : Use MATLAB default for Truncated SVD, or assign like 1.5e-1
NoTr = 20;    % Number of Trial
%====================================

Alld2pc = []; Alldeepc = []; 
for k_ = kFrom:kDelta:kTo
    jNbar = k_;  kTini = k_;    
    fprintf('-------- SIMULATION: PARA = %d -------------------- \n', k_);
    
    run_me_v4
    
    Alld2pc = [Alld2pc; MAEd2pc jNbar];        
    Alldeepc = [Alldeepc; MAEdeepc kTini];        
end

d2p1 = Alld2pc(:,1); xx1 = Alld2pc(:,2);  %nx
xlab = 'Nbar'; ylab = 'MAE';        

%===== Parameters of simulation =====
model = 'TwoCart';
AnOn = 0.1; % Online noise
AnOff = 0.1;  % Offline noise
kFrom = 4; kTo = 70; kDelta = 2; 
Nd1 = 1; % Nd for (A,B) average        
Nd2 = 1; % Nd for YU average
SkipDeePC = true; 
pinv_threshold = []; % [] : Use MATLAB default for Truncated SVD, or assign like 1.5e-1
%NoTr = 20;    % Number of Trial
%====================================

Alld2pc = []; Alldeepc = []; 
for k_ = kFrom:kDelta:kTo
    jNbar = k_;  kTini = k_;    
    fprintf('-------- SIMULATION: PARA = %d -------------------- \n', k_);

    run_me_v4
    
    Alld2pc = [Alld2pc; MAEd2pc jNbar];        
    Alldeepc = [Alldeepc; MAEdeepc kTini];        
end

d2p2 = Alld2pc(:,1); 

%===== Parameters of simulation =====
model = 'TwoCart';
AnOn = 0.1; % Online noise
AnOff = 0.1;  % Offline noise
kFrom = 4; kTo = 70; kDelta = 2; 
Nd1 = 1; % Nd for (A,B) average        
Nd2 = 5; % Nd for YU average
SkipDeePC = true; 
pinv_threshold = []; % [] : Use MATLAB default for Truncated SVD, or assign like 1.5e-1
%NoTr = 20;    % Number of Trial
%====================================

Alld2pc = []; Alldeepc = []; 
for k_ = kFrom:kDelta:kTo
    jNbar=k_;  kTini=k_;    
        
    fprintf('-------- SIMULATION: PARA = %d -------------------- \n', k_);
    
    run_me_v4
    
    Alld2pc = [Alld2pc; MAEd2pc jNbar];        
    Alldeepc = [Alldeepc; MAEdeepc kTini];        
end

d2p3 = Alld2pc(:,1); 

%===== Parameters of simulation =====
model = 'TwoCart';
AnOn = 0.1; % Online noise
AnOff = 0;  % Offline noise
kFrom = 4; kTo = 70; kDelta = 2; 
Nd1 = 1; % Nd for (A,B) average        
Nd2 = 100; % Nd for YU average
SkipDeePC = true; 
pinv_threshold = []; % [] : Use MATLAB default for Truncated SVD, or assign like 1.5e-1
%NoTr = 20;    % Number of Trial
%====================================

Alld2pc = []; Alldeepc = []; 
for k_ = kFrom:kDelta:kTo
    jNbar=k_;  kTini=k_;    
    fprintf('-------- SIMULATION: PARA = %d -------------------- \n', k_);

    run_me_v4
    
    Alld2pc = [Alld2pc; MAEd2pc jNbar];        
    Alldeepc = [Alldeepc; MAEdeepc kTini];        
end

d2p4 = Alld2pc(:,1);
        
figure(11)
clf
subplot(221)
leg1='Aoff=0';leg2='Nd=1';leg3='Nd=5';leg4='Nd=100';
plot(xx1,d2p1,'r',xx1,d2p2,'b:',xx1,d2p3,'b-.',xx1,d2p4,'b--');
xlim([4 20]);     ylim([0 0.6])
xlabel(xlab);ylabel(ylab);grid;
legend(leg1,leg2,leg3,leg4);

subplot(222)
plot(xx1,d2p1,'r',xx1,d2p2,'b:',xx1,d2p3,'b-.',xx1,d2p4,'b--');
xlim([20 70])
legend(leg1,leg2,leg3,leg4);
xlabel(xlab);ylabel(ylab);grid;
        